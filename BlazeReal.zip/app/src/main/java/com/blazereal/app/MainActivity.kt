package com.blazereal.app
class MainActivity{}