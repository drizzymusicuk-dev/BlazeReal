package com.blazereal.app
class FeedAdapter{}