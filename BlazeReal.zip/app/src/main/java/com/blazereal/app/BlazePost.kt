package com.blazereal.app
class BlazePost{}