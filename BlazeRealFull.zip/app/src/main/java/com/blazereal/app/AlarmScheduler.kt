
package com.blazereal.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.*

class AlarmScheduler(private val ctx: Context) {

    fun scheduleDaily420Alarms() {
        schedule(4, 20, 0)
        schedule(16, 20, 1)
    }

    private fun schedule(hour: Int, min: Int, req: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, req, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, min)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
        }

        if (Build.VERSION.SDK_INT >= 23)
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else
            am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}
