
package com.blazereal.app

import android.Manifest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class CameraActivity: AppCompatActivity() {

    private lateinit var backPreview: PreviewView
    private lateinit var frontPreview: PreviewView
    private lateinit var captureBtn: ImageButton

    private lateinit var capBack: ImageCapture
    private lateinit var capFront: ImageCapture

    private var swapped=false

    private val camPerm=registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ){granted ->
        if(granted) startCam() else finish()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_camera)

        backPreview=findViewById(R.id.backPreview)
        frontPreview=findViewById(R.id.frontPreview)
        captureBtn=findViewById(R.id.captureBtn)

        camPerm.launch(Manifest.permission.CAMERA)

        frontPreview.setOnClickListener {
            swapped=!swapped
            startCam()
        }

        captureBtn.setOnClickListener {
            captureBoth()
        }
    }

    private fun startCam(){
        val fut=ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val provider=fut.get()
            provider.unbindAll()

            val prevBack=Preview.Builder().build()
            val prevFront=Preview.Builder().build()

            capBack=ImageCapture.Builder().build()
            capFront=ImageCapture.Builder().build()

            val selBack=if(!swapped) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
            val selFront=if(!swapped) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA

            prevBack.setSurfaceProvider(backPreview.surfaceProvider)
            prevFront.setSurfaceProvider(frontPreview.surfaceProvider)

            provider.bindToLifecycle(this, selBack, prevBack, capBack)
            provider.bindToLifecycle(this, selFront, prevFront, capFront)

        },ContextCompat.getMainExecutor(this))
    }

    private fun captureBoth(){
        capture(capBack){b ->
            capture(capFront){f ->
                val merged=merge(b,f)
                save(merged)
                finish()
            }
        }
    }

    private fun capture(cap:ImageCapture, cb:(Bitmap)->Unit){
        val f=File(cacheDir,"tmp_${System.currentTimeMillis()}.jpg")
        val out=ImageCapture.OutputFileOptions.Builder(f).build()
        cap.takePicture(out,ContextCompat.getMainExecutor(this),
            object:ImageCapture.OnImageSavedCallback{
                override fun onError(exc: ImageCaptureException){}
                override fun onImageSaved(res:ImageCapture.OutputFileResults){
                    val bmp=android.graphics.BitmapFactory.decodeFile(f.absolutePath)
                    cb(bmp)
                }
        })
    }

    private fun merge(back:Bitmap, front:Bitmap):Bitmap{
        val r=Bitmap.createBitmap(back.width, back.height, Bitmap.Config.ARGB_8888)
        val c=Canvas(r)
        c.drawBitmap(back,0f,0f,null)
        val small=Bitmap.createScaledBitmap(front,200,200,true)
        c.drawBitmap(small,40f,40f,null)
        return r
    }

    private fun save(bmp:Bitmap){
        val dir=File(filesDir,"BlazeReal")
        dir.mkdirs()
        val name="BR_${SimpleDateFormat("yyyy_MM_dd_HH_mm", Locale.US).format(Date())}.png"
        val f=File(dir,name)
        f.outputStream().use{
            bmp.compress(Bitmap.CompressFormat.PNG,100,it)
        }
    }
}
