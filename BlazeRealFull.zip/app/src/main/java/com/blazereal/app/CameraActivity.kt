package com.blazereal.app

import android.Manifest
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.core.CameraSelector
import androidx.core.content.ContextCompat
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.FrameLayout
import android.widget.ImageView

class CameraActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: ImageView

    private val perm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ){ granted ->
        if (granted) startCamera() else finish()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        previewView = PreviewView(this)

        overlay = ImageView(this).apply {
            setBackgroundResource(R.xml.neon_glow)
            layoutParams = FrameLayout.LayoutParams(300,300).apply {
                leftMargin = 20; topMargin = 20
            }
        }

        val root = FrameLayout(this)
        root.addView(previewView)
        root.addView(overlay)
        setContentView(root)

        perm.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera(){
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val camSel = CameraSelector.DEFAULT_BACK_CAMERA
            provider.unbindAll()
            provider.bindToLifecycle(this, camSel, preview)
        }, ContextCompat.getMainExecutor(this))
    }
}