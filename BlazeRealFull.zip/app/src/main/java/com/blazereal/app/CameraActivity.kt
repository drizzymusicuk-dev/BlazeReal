
package com.blazereal.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class CameraActivity: AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_camera)
    }
}
