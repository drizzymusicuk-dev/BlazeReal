package com.blazereal.app

import android.content.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            AlarmScheduler(c).scheduleAll420Alarms()
        }
    }
}