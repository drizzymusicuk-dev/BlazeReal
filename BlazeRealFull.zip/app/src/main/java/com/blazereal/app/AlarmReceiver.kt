
package com.blazereal.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver: BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent?) {

        val channelId="blazereal420"
        val nm=NotificationManagerCompat.from(ctx)

        if(android.os.Build.VERSION.SDK_INT>=26){
            val ch=android.app.NotificationChannel(
                channelId,"420 Alerts",
                android.app.NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(ch)
        }

        val openCam=Intent(ctx, CameraActivity::class.java)
        val pi=PendingIntent.getActivity(
            ctx,0,openCam,PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n=NotificationCompat.Builder(ctx,channelId)
            .setContentTitle("420 Check! Spark Up ✨")
            .setContentText("BlazeReal is waiting… you already know what to do 😤🔥")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setColor(0x00FF44)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        nm.notify(420,n)
    }
}
