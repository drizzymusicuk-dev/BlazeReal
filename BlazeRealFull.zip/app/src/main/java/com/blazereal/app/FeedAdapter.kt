
package com.blazereal.app
import android.view.*
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class FeedAdapter: RecyclerView.Adapter<FeedAdapter.Holder>() {
    class Holder(v: View): RecyclerView.ViewHolder(v)
    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        Holder(LayoutInflater.from(p.context).inflate(R.layout.item_post, p, false))
    override fun onBindViewHolder(h: Holder, i: Int) {}
    override fun getItemCount() = 0
}
