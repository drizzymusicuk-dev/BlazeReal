package com.blazereal.app

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class BlazeReminderService : Service() {

    private val channelId = "blazereal420"
    private val notifId = 420420

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(notifId, initialNotification())

        Thread {
            val vib = getSystemService(VIBRATOR_SERVICE) as Vibrator

            for (i in 1..5) {
                Thread.sleep(60000)
                vib.vibrate(VibrationEffect.createOneShot(400, 200))
                updateNotification("$i minutes since 4:20 🔥💨")
            }

            finishReminder()
        }.start()

        return START_NOT_STICKY
    }

    private fun initialNotification(): Notification {
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_weed_leaf_white)
            .setContentTitle("🔥 420 CHECK BRO 🔥 Spark Up ✨")
            .setContentText("BlazeReal is waiting… grab your phone AND your lighter 😤💨💚")
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_weed_leaf_white)
            .setContentTitle("420 Reminder")
            .setContentText(text)
            .setOngoing(true)
            .build()
        nm.notify(notifId, notif)
    }

    private fun finishReminder() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 999, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val finalNotif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_weed_leaf_white)
            .setContentTitle("You missed the moment 😭💨")
            .setContentText("Tap to open BlazeReal anyway.")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()

        nm.notify(notifId + 1, finalNotif)

        stopForeground(false)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}