package com.blazereal.app 

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity 

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        AlarmScheduler(this).scheduleAll420Alarms()
    }
}
