package com.blazereal.app

import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        val channelId = "blazereal420"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channel = NotificationChannel(
            channelId,
            "BlazeReal 420 Alerts",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(channel)

        val notif = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_weed_leaf_white)
            .setContentTitle("🔥 420 CHECK BRO 🔥 Spark Up ✨")
            .setContentText("BlazeReal is waiting… grab your phone AND your lighter 😤💨💚")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        nm.notify(420420, notif)

        val sIntent = Intent(context, BlazeReminderService::class.java)
        context.startForegroundService(sIntent)
    }
}